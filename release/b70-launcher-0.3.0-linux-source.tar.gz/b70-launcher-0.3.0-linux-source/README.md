# B70 Launcher 0.3.0 (Linux source release)

Inspect local Arc Pro B70 hardware, find cookbook model artifacts, review the exact engine command, and optionally launch an inference server. This is a local browser UI backed by Python stdlib; it does **not** bundle an engine, model weights, Docker, drivers, or a browser.

Copyright retained by its owner. This owner-published source download does not grant a general redistribution, modification, or open-source license. Only the launcher source, recipe data, UI, and launcher-created icon are staged; Intel logos and third-party engine artwork are excluded. The UI makes no network requests until the user selects a model download (or a launched engine pulls its configured image/model). Verify the release manifest and checksum before sharing.

## Install (current user only)

1. Verify the archive with the separately supplied SHA256 checksum: `sha256sum -c b70-launcher-0.3.0-linux-source.tar.gz.sha256`.
2. Extract it: `tar -xzf b70-launcher-0.3.0-linux-source.tar.gz`.
3. Inspect `launcher.py`, `recipes.json`, `settings.json`, and `packaging/install.sh`; run `sh b70-launcher-0.3.0-linux-source/packaging/install.sh` if satisfied. Installer copies the inspectable source to `~/.local/share/b70-launcher`, adds `~/.local/bin/b70-launcher` and a desktop entry in `~/.local/share/applications` (XDG_DATA_HOME is honored for the app and entry). No root access or global system changes. Start from your application menu or run `~/.local/bin/b70-launcher`.

Python 3.9+ and a graphical browser are required for the UI. To actually launch a GPU engine, install a compatible Linux Intel GPU driver, accessible DRM render nodes, Docker daemon/CLI with Intel GPU support and permission to use it, adequate disk/VRAM, and a valid model artifact. Docker access is effectively root-equivalent; do not grant it to untrusted users. The UI shows render-node identification and basic blockers before launch. A preflight success does **not** certify an engine, quantization, context size, power budget, or card topology. No engine starts at installation or first opening. Container images may be pulled when launching; review recipes and image provenance first. Some recipe images use mutable tags.

The installer does not overwrite system files but does replace an existing user-level B70 Launcher installation. Model downloads write into `~/models` or `~/models/ovms-repo`; inspect repository and model license before requesting them. Automatic download is limited to recipe-pinned OpenVINO/Intel Hugging Face repositories after an explicit click; other recipes require manual artifact acquisition. A pinned repository is **not** a content signature: upstream `main` may change, and equal-sized existing files are reused without cryptographic verification; mismatched/unknown existing artifacts are never overwritten automatically. Do not treat model weights as trusted code; some engines may execute model-defined custom code. No automatic power cap is applied and no generic power-cap command is supplied; identify a board-safe cap and exact GPU node yourself if needed.

## Support boundary

- **B70:** This UI and cookbook command templates target the Arc Pro B70 on Linux. Recipes reflect specific benchmark/cookbook configurations, not a blanket validation of every model/engine combination. In particular, Qwen3.8 OpenVINO IR was a research failure; no working OpenVINO recipe is offered for it.
- **B50/B60/B65 and other Intel GPUs:** Not validated by this launcher. The preflight deliberately blocks real launches when it cannot identify accessible B70 render nodes; use dry-run to inspect commands. Do not infer compatibility from shared Intel branding.
- **Card count:** Real launches require exactly one accessible, identified B70 at selected index 0 or 1. The UI disables the second-card checkbox and the API blocks two-card launches because topology and engine compatibility are unvalidated; dry-run may preview two-card commands for inspection only. More than two GPUs are unsupported.
- **Windows:** Python source may open the UI, but GPU launch is intentionally blocked. WSL2/Docker passthrough is not validated; the Linux desktop archive/installer is not a Windows installer.

`settings.json` lists portable default scan roots. Edit the installed file if your storage layout differs and restart the app. The localhost API is bound to `127.0.0.1` with an in-page per-process token for POST requests and Host/Origin checks; do not expose it through a proxy or share a desktop session with untrusted users. Logs live under `${XDG_STATE_HOME:-~/.local/state}/b70-launcher/logs`. Quit the UI with Ctrl-C when started in a terminal. `--no-open` runs without opening a browser.

## Repackage from checked-out sources

Run `python3 packaging/release.py`; it emits `release/b70-launcher-0.3.0-linux-source.tar.gz`, `.sha256`, and `.manifest.json` (explicit staged paths and per-file SHA256). This reproducible source bundle excludes the old PyInstaller `dist/` binary: that ELF uses glibc and bundled Python shared libraries and has no demonstrated portable runtime/ABI support. Its presence in the working tree is not a release. The release is inspectable source, not self-contained executable; Python and runtime dependencies above remain prerequisites.
