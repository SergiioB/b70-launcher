#!/bin/sh
# Install this inspected source bundle in the current user's home only.
set -eu
command -v python3 >/dev/null 2>&1 || { echo 'Python 3.9+ is required' >&2; exit 1; }
root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
app="${XDG_DATA_HOME:-$HOME/.local/share}/b70-launcher"
bin="$HOME/.local/bin"
desktop="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
mkdir -p "$app/web/assets" "$bin" "$desktop"
cp "$root/launcher.py" "$root/recipes.json" "$root/settings.json" "$root/README.md" "$app/"
cp "$root/web/index.html" "$app/web/"
cp "$root/web/assets/b70-launcher.svg" "$app/web/assets/"
cat > "$bin/b70-launcher" <<EOF
#!/bin/sh
exec python3 "$app/launcher.py" "\$@"
EOF
chmod 755 "$bin/b70-launcher"
cat > "$desktop/b70-launcher.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=B70 Launcher
Comment=Inspect local hardware and launch selected B70 inference recipes
Exec=$bin/b70-launcher
Icon=$app/web/assets/b70-launcher.svg
Terminal=false
Categories=Utility;
EOF
chmod 644 "$desktop/b70-launcher.desktop"
printf 'Installed %s and %s\nNo engine, model, Docker image, or power setting changed.\n' "$bin/b70-launcher" "$desktop/b70-launcher.desktop"
