#!/usr/bin/env python3
"""Local UI for inspecting B70 hardware, approved model artifacts and launch recipes.

Python stdlib only. Linux GPU execution requires a verified single B70, driver,
Docker, model and explicit launch consent. Other Intel cards and Windows GPU
execution are not validated by this release.
"""
import argparse
import glob
import json
import os
import re
import secrets
import shlex
import shutil
import subprocess
import stat
import sys
import threading
import time
import urllib.parse
import urllib.request
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
HERE = Path(sys.executable).parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
RECIPES = json.loads((HERE / "recipes.json").read_text())
SETTINGS = json.loads((HERE / "settings.json").read_text())
DATA = Path(os.environ.get("XDG_STATE_HOME", Path.home() / ".local" / "state")) / "b70-launcher"
DATA.mkdir(parents=True, exist_ok=True)
LOGDIR = DATA / "logs"
LOGDIR.mkdir(exist_ok=True)
API_TOKEN = secrets.token_urlsafe(32)

IS_WIN = os.name == "nt"
RUNNING = {}   # id -> server entry
DOWNLOADS = {}  # id -> download entry
SCAN = {"items": {"gguf": {}, "snapshots": {}}, "roots": [], "ts": 0}
LOCK = threading.Lock()

HF = "https://huggingface.co"
UA = {"User-Agent": "b70-launcher/0.3"}


# ---------------------------------------------------------------- scan / detect

def scan_roots():
    roots = []
    for r in SETTINGS.get("scan_dirs", []):
        p = Path(r).expanduser()
        if p.is_dir() and p not in roots:
            roots.append(p)
    return roots


def read_ctx_from_config(cfgpath):
    try:
        cfg = json.loads(Path(cfgpath).read_text())
    except Exception:
        return None
    for key in ("max_position_embeddings", "context_length", "max_seq_len", "n_ctx"):
        v = cfg.get(key)
        if isinstance(v, int) and v > 512:
            return v
    return None


def scan():
    """Find GGUF files and HF snapshot dirs under the scan roots."""
    items = {"gguf": {}, "snapshots": {}}
    roots = scan_roots()
    for root in roots:
        try:
            for p in root.rglob("*.gguf"):
                if p.is_file() and not p.is_symlink():
                    items["gguf"].setdefault(p.name.lower(), str(p))
            for d in root.rglob("*"):
                if not d.is_dir() or d.is_symlink():
                    continue
                cfg = d / "config.json"
                ov = any(d.glob("openvino_language_model.*"))
                if cfg.exists() or ov:
                    ctx = read_ctx_from_config(cfg) if cfg.exists() else None
                    items["snapshots"][d.name.lower()] = {
                        "path": str(d),
                        "repo_hint": f"{d.parent.name}/{d.name}",
                        "ctx": ctx,
                    }
        except PermissionError:
            continue
    with LOCK:
        SCAN.update({"items": items, "roots": [str(r) for r in roots], "ts": time.time()})
    return items, roots


def _norm(s):
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def detect(model, engine):
    """Match a recipe to an on-disk artifact: exact name first, else same model family."""
    items = SCAN.get("items") or scan()[0]
    r = model["recipes"].get(engine, {})
    dl = r.get("download", {})
    pool = items["gguf"] if dl.get("kind") == "file" else items["snapshots"]
    want = (dl.get("name") or "").lower()
    key = _norm(dl.get("match") or dl.get("search") or dl.get("name")
                or r.get("search_name")
                or (dl.get("repo") or r.get("source_model") or "").split("/")[-1])

    def wrap(name, hit, exact):
        path = hit if isinstance(hit, str) else hit["path"]
        ctx = None if isinstance(hit, str) else hit.get("ctx")
        p = Path(path)
        roots = [Path(x) for x in SCAN.get("roots", [])]
        mount = p.parent.parent if p.parent.parent in roots else p.parent
        return {"path": path, "ctx": ctx, "mount_root": str(mount),
                "found_name": name, "variant": not exact}

    if want and want in pool:
        return wrap(want, pool[want], True)
    prefer = [_norm(p) for p in dl.get("prefer", [])]
    cands = []
    for name, hit in pool.items():
        nn = _norm(name)
        if name.startswith("mmproj"):
            continue  # vision sidecar is never the model itself
        if prefer and not any(p in nn for p in prefer):
            continue  # right model, wrong artifact format for this engine
        if key and key in nn:
            score = sum(1 for p in prefer if p and p in nn) - len(nn) / 1000.0
            cands.append((score, name, hit))
    if cands:
        cands.sort(key=lambda t: (-t[0], t[1]))
        _, name, hit = cands[0]
        return wrap(name, hit, name == want)
    return None


def resolve_ctx(model, engine, det):
    r = model["recipes"].get(engine, {})
    cap = r.get("ctx_max")
    if det and det.get("ctx"):
        v = det["ctx"]
        if cap:
            v = min(v, cap)
        return {"value": v, "source": "config.json on disk"}
    v = r.get("ctx", 32768)
    if cap:
        v = min(v, cap)
    return {"value": v, "source": r.get("ctx_note", "cookbook recipe")}


# ---------------------------------------------------------------- HF resolve

def _http_json(url):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read())



def hf_files(repo):
    data = _http_json(f"{HF}/api/models/{repo}?blobs=true")
    files = {}
    for sib in data.get("siblings", []):
        lfs = sib.get("lfs") or {}
        size = sib.get("size") or lfs.get("size")
        files[sib["rfilename"]] = size
    return files


def resolve_repo(dl):
    """Only a recipe-pinned repository is suitable for automatic download."""
    repo = dl.get("repo", "")
    if repo not in ("OpenVINO/Qwen3.6-35B-A3B-int4-ov", "Intel/Qwen3.6-27B-int4-AutoRound"):
        return None, "Automatic download unavailable: recipe has no approved official HF repository. Obtain and inspect the artifact manually."
    return repo, None


def safe_artifact(name):
    """Reject absolute/traversing HF filenames (including Windows separators)."""
    parts = name.split("/")
    return bool(name and not name.startswith("/") and "\\" not in name and ":" not in name and all(p not in ("", ".", "..") for p in parts))


def hardware_preflight():
    devices = []
    if IS_WIN:
        return {"devices": devices, "blockers": ["Windows GPU execution is not validated; use a supported Linux host."], "notes": []}
    for render in sorted(Path("/sys/class/drm").glob("renderD*"), key=lambda p: int(p.name.removeprefix("renderD"))):
        dev = render / "device"
        try:
            vendor = (dev / "vendor").read_text().strip().lower()
            device = (dev / "device").read_text().strip().lower()
            subsystem_vendor = (dev / "subsystem_vendor").read_text().strip().lower()
            subsystem_device = (dev / "subsystem_device").read_text().strip().lower()
            pci = dev.resolve().name
            label = ""
            if shutil.which("lspci"):
                label = subprocess.run(["lspci", "-s", pci], capture_output=True,
                                       text=True, timeout=3).stdout.strip()
            b70 = (vendor, device, subsystem_vendor, subsystem_device) == ("0x8086", "0xe223", "0x8086", "0x1701")
            devices.append({"render": f"/dev/dri/{render.name}", "pci": pci,
                            "vendor": vendor, "device": device, "label": label,
                            "accessible": os.access(f"/dev/dri/{render.name}", os.R_OK | os.W_OK),
                            "b70": b70})
        except (OSError, subprocess.TimeoutExpired):
            continue
    blockers = []
    if not devices:
        blockers.append("No DRM render nodes found; install a working Intel GPU driver.")
    if not any(d["b70"] for d in devices):
        blockers.append("No Arc Pro B70 identified by Intel PCI subsystem ID 8086:1701; other Intel GPUs are unvalidated.")
    if not shutil.which("docker"):
        blockers.append("Docker CLI missing; install Docker and a supported GPU runtime.")
    if os.environ.get("DOCKER_HOST") or os.environ.get("DOCKER_CONTEXT"):
        blockers.append("Docker remote context/environment configured; only a local Docker socket is supported.")
    socket_path = Path(os.environ.get("XDG_RUNTIME_DIR", "/run/user/" + str(os.getuid())) + "/docker.sock")
    if not socket_path.exists():
        socket_path = Path("/var/run/docker.sock")
    try:
        if not stat.S_ISSOCK(socket_path.stat().st_mode) or not os.access(socket_path, os.R_OK | os.W_OK):
            blockers.append("Local Docker socket unavailable or inaccessible.")
    except OSError:
        blockers.append("Local Docker socket unavailable or inaccessible.")
    return {"devices": devices, "blockers": blockers,
            "notes": ["GPU container compatibility and model fit are not proven by this preflight."]}


# ---------------------------------------------------------------- downloads

def fmt_bytes(n):
    if n is None:
        return "?"
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} PB"


def fmt_eta(sec):
    if sec is None or sec < 0:
        return "--:--"
    sec = int(sec)
    h, rem = divmod(sec, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def _download_file(url, dest, entry):
    """Stream to dest with HTTP Range resume across network failures (HF/Xet 403s)."""
    tmp = dest.with_suffix(dest.suffix + ".part")
    if tmp.is_symlink():
        raise ValueError("Refusing symlinked partial download")
    counted = 0  # bytes of THIS file already reflected in entry["done"]
    last_err = None
    for attempt in range(4):
        try:
            existing = tmp.stat().st_size if tmp.exists() else 0
            headers = dict(UA)
            if existing:
                headers["Range"] = f"bytes={existing}-"
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=60) as resp:
                if existing and getattr(resp, "status", 200) != 206:
                    existing = 0  # server ignored Range -> restart this file
                if counted > existing:
                    entry["done"] = entry.get("done", 0) - counted
                    counted = 0
                if existing and not counted:
                    entry["done"] = entry.get("done", 0) + existing
                    counted = existing
                total = resp.headers.get("Content-Length")
                if total and not entry.get("total"):
                    entry["total"] = entry.get("done", 0) + int(total) + (
                        existing if counted != existing else 0)
                last = time.time()
                speed = 0.0
                with open(tmp, "ab" if existing else "wb") as f:
                    while True:
                        if entry.get("cancel"):
                            raise InterruptedError("cancelled")
                        chunk = resp.read(1 << 20)
                        if not chunk:
                            break
                        f.write(chunk)
                        now = time.time()
                        inst = len(chunk) / max(now - last, 1e-6)
                        speed = inst if speed == 0 else 0.8 * speed + 0.2 * inst
                        last = now
                        entry["done"] = entry.get("done", 0) + len(chunk)
                        counted += len(chunk)
                        entry["speed"] = speed
                        total_all = entry.get("total")
                        if total_all:
                            left = max(total_all - entry["done"], 0)
                            entry["eta"] = left / speed if speed > 0 else None
                            entry["pct"] = round(100 * entry["done"] / total_all, 1)
            if dest.exists():
                raise FileExistsError(f"Refusing to overwrite existing artifact: {dest}")
            tmp.rename(dest)
            return
        except InterruptedError:
            raise
        except Exception as e:
            last_err = e
            if attempt == 3:
                break
            time.sleep(2 * (attempt + 1))  # resume picks up from .part on retry
    raise RuntimeError(f"download failed after 4 attempts: {last_err}")


def download_worker(did, model, engine):
    entry = DOWNLOADS[did]
    try:
        entry["state"] = "resolving"
        dl = model["recipes"][engine]["download"]
        repo, err = resolve_repo(dl)
        if err:
            entry["state"] = "error"
            entry["error"] = err
            return
        entry["repo"] = repo
        files = hf_files(repo)
        if dl.get("kind") == "file":
            wanted = [dl["name"]] + list(dl.get("extra_files", []))
            dest_dir = Path(SETTINGS.get("models_dir", "~/models")).expanduser()
        else:
            wanted = list(files.keys())
            root = Path(SETTINGS.get("ovms_repo", "~/models/ovms-repo")).expanduser()
            if engine != "openvino":
                root = Path(SETTINGS.get("models_dir", "~/models")).expanduser()
            dest_dir = root / repo.split("/")[-1]
        if not wanted or any(not safe_artifact(w) for w in wanted):
            raise ValueError("Repository contains unsafe or empty artifact paths")
        if dl.get("kind") == "file" and any(w not in files for w in wanted):
            raise ValueError("Pinned repository does not contain the exact recipe filename")
        dest_dir.mkdir(parents=True, exist_ok=True)
        total_known = sum((files.get(w) or 0) for w in wanted if w in files)
        entry.update({"state": "downloading", "files": wanted, "done": 0,
                      "total": total_known or None, "dest": str(dest_dir)})
        for w in wanted:
            dest = dest_dir / w
            if dest.is_symlink() or not dest.parent.resolve().is_relative_to(dest_dir.resolve()):
                raise ValueError("Refusing download through symlink or outside destination")
            if dest.exists():
                if files.get(w) and dest.stat().st_size == files[w]:
                    entry["done"] += files[w]
                    continue
                raise FileExistsError(f"Existing artifact has unknown or mismatched size; move it aside manually: {dest}")
            dest.parent.mkdir(parents=True, exist_ok=True)
            url = f"{HF}/{repo}/resolve/main/{urllib.parse.quote(w)}"
            _download_file(url, dest, entry)
        entry["state"] = "done"
        entry["pct"] = 100
        entry["eta"] = 0
        scan()
    except InterruptedError:
        entry["state"] = "cancelled"
    except Exception as e:
        entry["state"] = "error"
        entry["error"] = str(e)


def start_download(model, engine):
    did = f"{model['id']}-{engine}"
    with LOCK:
        if did in DOWNLOADS and DOWNLOADS[did].get("state") in ("resolving", "downloading"):
            return did, None
        DOWNLOADS[did] = {"id": did, "model": model["name"], "engine": engine,
                          "state": "queued", "done": 0, "total": None, "pct": 0,
                          "speed": 0, "eta": None,
                          "quant": model["recipes"][engine].get("download", {}).get("quant", "")}
    t = threading.Thread(target=download_worker, args=(did, model, engine), daemon=True)
    t.start()
    return did, None


# ---------------------------------------------------------------- command build

def render_gid(render_node):
    try:
        return os.stat(render_node).st_gid
    except OSError:
        return None


def pretty(tokens, width=96):
    sep = " ^" if IS_WIN else " \\"
    lines, cur = [], ""
    for tok in tokens:
        quoted = tok if IS_WIN else shlex.quote(tok)
        candidate = (cur + " " + quoted).strip()
        if cur and len(candidate) > width:
            lines.append(cur + sep)
            cur = "    " + quoted
        else:
            cur = candidate
    lines.append(cur)
    return "\n".join(lines)


def find_model(model_id):
    for m in RECIPES["models"]:
        if m["id"] == model_id:
            return m
    return None


def container_path(det, fallback):
    """Map an on-disk path to the container's /models mount."""
    if not det or not det.get("path"):
        return fallback, None
    root = Path(det["mount_root"])
    rel = Path(det["path"]).relative_to(root)
    return "/models/" + str(rel).replace(os.sep, "/"), str(root)


def build(cfg):
    model = find_model(cfg.get("model_id", ""))
    engine = cfg.get("engine", "openvino")
    recipe = (model or {}).get("recipes", {}).get(engine)
    warns = []
    if not model or not recipe:
        return {"error": "no recipe for that model+engine", "warnings": warns}

    det = detect(model, engine)
    ctxres = resolve_ctx(model, engine, det)
    artifact_mib = None
    if det and det.get("path"):
        try:
            p = Path(det["path"])
            artifact_mib = (p.stat().st_size if p.is_file()
                            else sum(f.stat().st_size for f in p.rglob("*") if f.is_file())) / 1048576
        except Exception:
            artifact_mib = None
    if det and det.get("variant"):
        warns.append(f"using your local \"{det.get('found_name')}\" — recipe default was "
                     f"{recipe.get('download', {}).get('name') or recipe.get('download', {}).get('search') or 'the listed quant'}")
    try:
        ctx = int(cfg["ctx"]) if cfg.get("ctx") else ctxres["value"]
        port = int(cfg.get("port") or 8000)
        slots = int(cfg.get("slots") or 1)
        extra = shlex.split(cfg.get("extra", "") or "")
    except (ValueError, TypeError) as exc:
        return {"error": f"Invalid context, port, slots or extra flags: {exc}", "warnings": warns}
    if recipe.get("ctx_max") and ctx > recipe["ctx_max"]:
        warns.append(f"ctx {ctx} > engine ceiling {recipe['ctx_max']} for this recipe — clamping.")
        ctx = recipe["ctx_max"]

    extra_env = {}
    for line in (cfg.get("extra_env") or "").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            if not re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]*", k.strip()):
                return {"error": "Invalid environment variable name", "warnings": warns}
            extra_env[k.strip()] = v.strip()
    envargs = [x for k, v in extra_env.items() for x in ("-e", f"{k}={v}")]
    gpus = cfg.get("gpus", [0])
    kv = cfg.get("kv") or "recipe default"
    env = {}
    kind = recipe.get("kind", "")
    if not isinstance(gpus, list) or not gpus or len(gpus) != len(set(map(str, gpus))) or any(type(g) is not int or g not in (0, 1) for g in gpus):
        return {"error": "Select one or two distinct GPU indices (0 or 1).", "warnings": warns}
    if len(gpus) > 1 and not cfg.get("dry_run"):
        return {"error": "Two-card engine topology has not been validated for this release; use one B70 or dry-run to inspect.", "warnings": warns}
    if not 1 <= port <= 65535 or not 1 <= slots <= 128 or not 512 <= ctx <= 262144:
        return {"error": "Port, slots, or context out of range.", "warnings": warns}
    preflight = hardware_preflight() if not IS_WIN else {"devices": []}
    if len(gpus) == 1 and gpus[0] < len(preflight["devices"]):
        render_node = preflight["devices"][gpus[0]]["render"]
    else:
        render_node = "/dev/dri"
    if len(gpus) > 1:
        warns.append("Two-card configuration is experimental and requires matching B70 GPUs, verified device order, sufficient PCIe bandwidth, and engine support.")

    if kind == "ovms":
        fallback_mount = cfg.get("models_dir") or SETTINGS.get("ovms_repo", "~/models/ovms-repo")
        if det:
            cpath, mount_src = container_path(det, fallback_mount)
            source_model = cpath[len("/models/"):]
        else:
            source_model = recipe["source_model"]
            mount_src = fallback_mount
            warns.append("model not detected on disk — command uses default paths (download it or point 'scan root' at it)")
        tokens = ["docker", "run", "-d", "--rm", "--name", f"b70-{model['id']}-ovms"]
        if not IS_WIN:
            gid = render_gid(render_node)
            tokens += ["--user", f"{os.getuid()}:{os.getuid() if gid is None else gid}",
                       "--device", render_node,
                       "--group-add", str(gid if gid is not None else "render")]
        tokens += ["-p", f"127.0.0.1:{port}:{port}", "-v", f"{Path(mount_src).expanduser()}:/models:rw"] + envargs + [
                   recipe["image"],
                   "--rest_port", str(port),
                   "--model_repository_path", "/models",
                   "--source_model", source_model,
                   "--task", "text_generation",
                   "--target_device", "GPU"]
        if recipe.get("tool_parser"):
            tokens += ["--tool_parser", recipe["tool_parser"]]
        if recipe.get("reasoning_parser"):
            tokens += ["--reasoning_parser", recipe["reasoning_parser"]]
        if recipe.get("cim_long_ctx") and ctx > 20480:
            tokens += ["--cache_interval_multiplier", str(recipe["cim_long_ctx"])]
        tokens += recipe.get("fixed_flags", []) + extra
        warns.append("OVMS manages KV internally (GPU INT4 KV supported). ctx is advisory here.")
        served_name = source_model
        cname = f"b70-{model['id']}-ovms"

    elif kind.startswith("vllm"):
        fallback = recipe.get("model_path", "/models/model")
        if det:
            model_path, mount_src = container_path(det, fallback)
            if mount_src is None:
                mount_src = cfg.get("models_dir") or SETTINGS.get("models_dir", "~/models")
        else:
            model_path = fallback
            mount_src = cfg.get("models_dir") or SETTINGS.get("models_dir", "~/models")
            warns.append("model not detected on disk — using recipe default path")
        # a single mapped render node enumerates as device 0 inside the container
        selector = "level_zero:" + ",".join(str(i) for i in range(len(gpus)))
        tokens = ["docker", "run", "-d", "--rm", "--name", f"b70-{model['id']}-vllm"]
        if not IS_WIN:
            tokens += ["--device", render_node,
                       "--group-add", str(render_gid(render_node) or "render"),
                       "-v", f"{Path.home() / '.cache' / 'huggingface'}:/root/.cache/huggingface:rw"]
        else:
            warns.append("Windows GPU passthrough is unvalidated; real launch blocked by preflight.")
        tokens += ["--ipc=host", "--shm-size=16g",
                   "-v", f"{Path(mount_src).expanduser()}:/models:ro",
                   "-p", f"127.0.0.1:{port}:{port}",
                   "-e", f"ONEAPI_DEVICE_SELECTOR={selector}",
                   "-e", "VLLM_OPENVINO_KVCACHE_SPACE=16"] + envargs + [
                   recipe["image"],
                   "--model", model_path,
                   "--dtype", recipe.get("dtype", "bfloat16"),
                   "--gpu-memory-utilization", "0.92",
                   "--max-model-len", str(ctx),
                   "--port", str(port)]
        if recipe.get("speculative") and cfg.get("mtp", True):
            tokens += ["--speculative-model", recipe["speculative"],
                       "--num-speculative-tokens", str(recipe.get("spec_tokens", 4))]
        if kv == "fp8" or recipe.get("kv") == "fp8":
            tokens += ["--kv-cache-dtype", "fp8"]
        if kind == "vllm-autoround":
            tokens += recipe.get("fixed_flags", [])
        if len(gpus) > 1:
            tokens += ["--tensor-parallel-size", str(len(gpus))]
            warns.append("Multi-GPU TP on XPU: verify the level_zero selector string on your driver (per Intel LLM-Scaler TP setup).")
        if slots > 1:
            tokens += ["--max-num-seqs", str(slots)]
        tokens += extra
        served_name = model["name"]
        cname = f"b70-{model['id']}-vllm"
        if kind == "vllm-autoround":
            warns.append("FP16 crash guard: dtype float16 + --enforce-eager is intentional (dt_bias crash on BF16 path).")

    elif kind == "gguf":
        fallback = recipe.get("gguf", "/models/model.gguf")
        if det:
            gpath, mount_src = container_path(det, fallback)
            if mount_src is None:
                mount_src = cfg.get("models_dir") or SETTINGS.get("models_dir", "~/models")
        else:
            gpath = fallback
            mount_src = cfg.get("models_dir") or SETTINGS.get("models_dir", "~/models")
            warns.append("model not detected on disk — using recipe default path")
        kv_map = {"q8_0": ["--cache-type", "q8_0"],
                  "q8_0/q4_1": ["--cache-type-k", "q8_0", "--cache-type-v", "q4_1"],
                  "f16": ["--cache-type", "f16"]}
        if kv == "f16":
            warns.append("f16 KV wastes VRAM with zero quality gain on these workloads. q8_0 recommended.")
        llama_bin = (SETTINGS.get("llama_bin") or "").strip()
        if llama_bin and not cfg.get("use_docker"):
            tokens = [llama_bin]
            env.update(extra_env)
            env.update({
                "ONEAPI_DEVICE_SELECTOR": "level_zero:" + ",".join(str(g) for g in gpus),
                "ZES_ENABLE_SYSMAN": "1", "SYCL_CACHE_PERSISTENT": "0",
                "SYCL_PI_LEVEL_ZERO_USE_IMMEDIATE_COMMANDLISTS": "1",
                "UR_L0_ENABLE_RELAXED_ALLOCATION_LIMITS": "1",
                "SYCL_DEVICE_FILTER": "level_zero",
                "ZE_FLAT_DEVICE_HIERARCHY": "COMPOSITE", "ZE_AFFINITY_MASK": str(gpus[0]),
            })
            warns.append("Native llama.cpp: run inside `source /opt/intel/oneapi/setvars.sh` shell if libs are missing.")
        else:
            tokens = ["docker", "run", "-d", "--rm", "--name", f"b70-{model['id']}-sycl"]
            if not IS_WIN:
                tokens += ["--device", render_node,
                           "--group-add", str(render_gid(render_node) or "render")]
            tokens += ["--ipc=host", "-v", f"{Path(mount_src).expanduser()}:/models:ro",
                       "-p", f"127.0.0.1:{port}:{port}", "-e", "ZES_ENABLE_SYSMAN=1"] + envargs + [
                       recipe["image"]]
        tokens += ["-m", gpath, "-ngl", "99", "--host", "0.0.0.0", "--port", str(port),
                   "-c", str(ctx), "--flash-attn"] + kv_map.get(kv, kv_map["q8_0"])
        if len(gpus) > 1:
            tokens += ["-ts", ",".join(["1"] * len(gpus))]
            warns.append("Dual-GPU is a capacity play, not speed: PCIe hop costs 10-50% (x4 worst).")
        if slots > 1:
            tokens += ["-np", str(slots)]
            warns.append("-np splits the context across slots (shared -c pool).")
        tokens += recipe.get("fixed_flags", []) + extra
        served_name = Path(gpath).stem
        cname = f"b70-{model['id']}-sycl"

    else:
        return {"error": f"unknown recipe kind {kind}", "warnings": warns}

    watts = int(cfg.get("power") or recipe.get("power") or 150)
    power_cmd = "Not generated: identify the exact GPU hwmon power1_cap and safe board limit manually. The launcher never changes power settings."
    return {
        "cmd": pretty(tokens), "tokens": tokens, "env": env, "warnings": warns,
        "power_cmd": power_cmd, "power": watts, "cname": cname,
        "endpoint": f"http://127.0.0.1:{port}/v1", "served_name": served_name,
        "model_name": model["name"], "engine": engine,
        "ctx": ctx, "ctx_source": "manual override" if cfg.get("ctx") else ctxres["source"],
        "detected": bool(det), "detected_path": (det or {}).get("path"),
        "artifact_mib": round(artifact_mib, 1) if artifact_mib else None,
    }


TOKS_RE = re.compile(r"([\d.]+)\s*tokens per second|throughput:\s*([\d.]+)\s*tokens/s", re.I)
MEM_RES = [
    (re.compile(r"([\d.]+)\s*(MiB|GiB)\s*VRAM used", re.I), "vram used (log)"),
    (re.compile(r"model weights take\s*([\d.]+)\s*GiB", re.I), "weights GiB (log)"),
    (re.compile(r"buffer size =\s*([\d.]+)\s*(MiB|GiB)", re.I), "buffer (log)"),
]


def vram_probe():
    """Best real VRAM reading the OS exposes, with its source. None = not exposed."""
    if IS_WIN:
        return None
    for usedp in sorted(glob.glob("/sys/class/drm/card*/device/mem_info_vram_used")):
        try:
            used = int(Path(usedp).read_text().strip())
            totalp = Path(usedp).parent / "mem_info_vram_total"
            total = int(totalp.read_text().strip()) if totalp.exists() else None
            return {"used_mib": round(used / 1048576, 1),
                    "total_mib": round(total / 1048576, 1) if total else None,
                    "source": "sysfs"}
        except Exception:
            continue
    return None


def metrics_snapshot():
    """Per-server tok/s + memory (from engine logs) + container cpu/mem (docker stats)."""
    stats = {}
    if RUNNING and shutil.which("docker") and not (os.environ.get("DOCKER_HOST") or os.environ.get("DOCKER_CONTEXT")):
        try:
            r = subprocess.run(
                ["docker", "stats", "--no-stream",
                 "--format", "{{.Name}}|{{.CPUPerc}}|{{.MemUsage}}"],
                capture_output=True, text=True, timeout=8)
            for line in r.stdout.splitlines():
                parts = line.split("|")
                if len(parts) == 3:
                    stats[parts[0]] = {"cpu": parts[1], "mem": parts[2]}
        except Exception:
            pass
    out = {}
    with LOCK:
        items = list(RUNNING.items())
    for rid, e in items:
        toks = mem = None
        try:
            tail = Path(e["log"]).read_text(errors="replace")[-8000:]
            ms = TOKS_RE.findall(tail)
            if ms:
                toks = ms[-1][0] or ms[-1][1]
            for rx, label in MEM_RES:
                mm = rx.findall(tail)
                if mm:
                    mem = f"{label}: {mm[-1][0]} {mm[-1][1] if len(mm[-1]) > 1 else ''}".strip()
                    break
        except Exception:
            pass
        out[rid] = {"toks": toks, "engine_mem": mem,
                    "stats": stats.get(e.get("cname", ""))}
    out["vram"] = vram_probe()
    if not out["vram"]:
        ests = [e.get("artifact_mib") for _, e in items if e.get("artifact_mib")]
        if ests:
            out["vram"] = {"used_mib": round(max(ests) * 1.1, 1), "total_mib": None,
                           "source": "estimate (file x1.1)"}
    return out


def harness_line(cfg, built):
    hs = {h["id"]: h for h in SETTINGS["harnesses"]}
    h = hs.get(cfg.get("harness", "omp"), hs["omp"])
    cmd = (cfg.get("harness_cmd") or "").strip() or h["cmd"]
    prefix = "" if IS_WIN else f"OPENAI_BASE_URL={built['endpoint']} OPENAI_API_KEY=local "
    return f"{prefix}{cmd}"


# ---------------------------------------------------------------- run / stop

def launch(cfg, built):
    rid = f"{cfg.get('model_id')}-{cfg.get('engine')}-{cfg.get('port') or 8000}"
    with LOCK:
        previous = RUNNING.get(rid)
        if previous and previous["status"] != "stopped":
            raise ValueError("A server with this model, engine, and port is already tracked. Stop it before launching again.")
    log = LOGDIR / f"{rid}-{int(time.time())}.log"
    entry = {"id": rid, "model": built["model_name"], "engine": built["engine"],
             "cfg": dict(cfg), "cname": built.get("cname", ""), "endpoint": built["endpoint"], "cmd": built["cmd"],
             "artifact_mib": built.get("artifact_mib"),
             "log": str(log), "started": time.strftime("%Y-%m-%d %H:%M:%S"),
             "status": "starting", "proc": None}
    if cfg.get("dry_run"):
        entry["status"] = "dry-run"
        with open(log, "ab") as lf:
            lf.write(("[dry-run] " + built["cmd"] + "\n").encode())
    else:
        env = dict(os.environ)
        env.update(built.get("env") or {})
        with open(log, "ab") as lf:
            lf.write((built["cmd"] + "\n").encode())
            lf.flush()
            entry["proc"] = subprocess.Popen(built["tokens"], env=env, stdout=lf,
                                             stderr=subprocess.STDOUT, cwd=str(HERE))
        entry["status"] = "running"
    with LOCK:
        RUNNING[rid] = entry
    return rid


def servers_snapshot():
    with LOCK:
        items = []
        for rid, e in RUNNING.items():
            proc = e.get("proc")
            status = e["status"]
            if proc is not None:
                rc = proc.poll()
                status = "running" if rc is None else f"exited ({rc})"
            if status == "stopped":
                continue
            items.append({k: v for k, v in e.items() if k != "proc"} | {"status": status})
        return items


def stop_server(rid):
    with LOCK:
        e = RUNNING.get(rid)
        if not e:
            return False
        proc = e.get("proc")
        cname = e.get("cname")
        if cname and e.get("proc") is not None:
            subprocess.run(["docker", "rm", "-f", cname], capture_output=True)
        if proc is not None and proc.poll() is None:
            proc.terminate()
        e["status"] = "stopped"
        return True


def open_harness(cfg, built):
    line = harness_line(cfg, built)
    if IS_WIN:
        subprocess.Popen(SETTINGS["terminal_windows"] + [line])
    else:
        term = list(SETTINGS["terminal_linux"])
        for cand in (term[0], "gnome-terminal", "xterm"):
            if shutil.which(cand):
                if cand == "gnome-terminal":
                    term = ["gnome-terminal", "--", "sh", "-c", line + "; exec sh"]
                else:
                    term[0] = cand
                    term = term + [line + "; exec sh"]
                subprocess.Popen(term)
                return line
    return line


# ---------------------------------------------------------------- http

class Handler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

    def _json(self, obj, code=200):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read(self):
        n = int(self.headers.get("Content-Length") or 0)
        if not 0 <= n <= 65536:
            raise ValueError("request body too large")
        obj = json.loads(self.rfile.read(n) or b"{}")
        if not isinstance(obj, dict):
            raise ValueError("expected a JSON object")
        return obj

    def _host_ok(self):
        host = self.headers.get("Host", "")
        return host in ("127.0.0.1", f"127.0.0.1:{self.server.server_port}")

    def do_GET(self):
        if not self._host_ok():
            self._json({"error": "invalid Host"}, 403)
            return
        if self.path in ("/", "/index.html"):
            body = (HERE / "web" / "index.html").read_bytes().replace(b"__API_TOKEN__", API_TOKEN.encode())
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Security-Policy", "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; base-uri 'none'; form-action 'none'; frame-ancestors 'none'")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        elif self.path == "/api/state":
            self._json({"recipes": RECIPES, "settings": SETTINGS,
                        "running": servers_snapshot(), "is_win": IS_WIN,
                        "preflight": hardware_preflight(),
                        "scan": {"roots": SCAN.get("roots", [])}})
        elif self.path == "/api/scan":
            scan()
            out = {}
            for m in RECIPES["models"]:
                out[m["id"]] = {}
                for eng in m["recipes"]:
                    det = detect(m, eng)
                    out[m["id"]][eng] = {
                        "detected": bool(det),
                        "path": (det or {}).get("path"),
                        "ctx_native": (det or {}).get("ctx"),
                    }
            self._json({"roots": SCAN.get("roots", []), "matches": out})
        elif self.path == "/api/metrics":
            self._json(metrics_snapshot())
        elif self.path.startswith("/api/logs"):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            with LOCK:
                e = RUNNING.get((q.get("id") or [""])[0])
            if not e:
                self._json({"error": "no such server"}, 404)
                return
            try:
                lines = Path(e["log"]).read_text(errors="replace").splitlines()[-60:]
            except Exception:
                lines = []
            self._json({"id": e["id"], "lines": lines})
        elif self.path == "/api/downloads":
            with LOCK:
                self._json({did: {k: v for k, v in e.items() if k != "cancel"}
                            for did, e in DOWNLOADS.items()})
        elif self.path.startswith("/assets/"):
            root = (HERE / "web").resolve()
            f = (root / self.path.lstrip("/")).resolve()
            if not f.is_relative_to(root) or not f.is_file():
                self._json({"error": "not found"}, 404)
                return
            ctype = {"svg": "image/svg+xml", "png": "image/png",
                     "jpg": "image/jpeg", "jpeg": "image/jpeg"}.get(f.suffix.lstrip("."), "application/octet-stream")
            body = f.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else:
            self._json({"error": "not found"}, 404)

    def do_POST(self):
        if (not self._host_ok() or self.headers.get("X-Launcher-Token") != API_TOKEN
                or self.headers.get("Origin") not in (None, f"http://127.0.0.1:{self.server.server_port}")
                or self.headers.get("Content-Type") != "application/json"):
            self._json({"error": "unauthorized request"}, 403)
            return
        try:
            cfg = self._read()
        except (ValueError, json.JSONDecodeError):
            self._json({"error": "invalid JSON body"}, 400)
            return
        if self.path == "/api/build":
            built = build(cfg)
            if "error" not in built:
                built["harness_line"] = harness_line(cfg, built)
                m = find_model(cfg.get("model_id", ""))
                if m:
                    built["download"] = m["recipes"].get(cfg.get("engine", ""), {}).get("download", {})
            self._json(built)
        elif self.path == "/api/launch":
            built = build(cfg)
            if "error" in built:
                self._json(built, 400)
                return
            if not cfg.get("dry_run"):
                check = hardware_preflight()
                if check["blockers"] or not built["detected"]:
                    self._json({"error": "; ".join(check["blockers"] or ["Model artifact not detected; download or configure scan roots first."])}, 400)
                    return
                selected = cfg.get("gpus", [0])
                if any(i >= len(check["devices"]) or not check["devices"][i]["b70"] or not check["devices"][i]["accessible"] for i in selected):
                    self._json({"error": "Selected render nodes are not identified accessible B70 GPUs; check permissions and device order."}, 400)
                    return
            try:
                rid = launch(cfg, built)
            except (OSError, ValueError) as exc:
                self._json({"error": str(exc)}, 400)
                return
            self._json({"id": rid, "harness_line": harness_line(cfg, built)})
        elif self.path == "/api/download":
            m = find_model(cfg.get("model_id", ""))
            if not m or cfg.get("engine") not in m["recipes"]:
                self._json({"error": "no such model+engine"}, 400)
                return
            did, err = start_download(m, cfg["engine"])
            self._json({"id": did, "error": err})
        elif self.path == "/api/stop":
            self._json({"ok": stop_server(cfg.get("id", ""))})
        elif self.path == "/api/harness":
            built = build(cfg)
            if "error" in built:
                self._json(built, 400)
                return
            self._json({"line": open_harness(cfg, built)})
        else:
            self._json({"error": "not found"}, 404)


def open_window(url):
    if IS_WIN:
        for browser in ("msedge", "chrome"):
            try:
                subprocess.Popen(["cmd", "/c", "start", "", browser, f"--app={url}"])
                return
            except OSError:
                continue
        webbrowser.open(url)
    else:
        for browser in ("chromium", "chromium-browser", "google-chrome", "microsoft-edge"):
            if shutil.which(browser):
                args = [browser, f"--app={url}", "--window-size=1440,900"]
                if os.environ.get("WAYLAND_DISPLAY"):
                    args.append("--ozone-platform=wayland")  # native on GNOME Wayland; "auto" rejected by some builds
                    args.append("--disable-features=Vulkan")  # snap Chromium: Vulkan incompatible with wayland ozone
                subprocess.Popen(args)
                return
        webbrowser.open(url)


def main():
    ap = argparse.ArgumentParser(description="B70 model launcher")
    ap.add_argument("--port", type=int, default=SETTINGS.get("port", 7570))
    ap.add_argument("--no-open", action="store_true", help="don't open the window")
    args = ap.parse_args()
    scan()
    url = f"http://127.0.0.1:{args.port}"
    try:
        srv = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    except OSError as exc:
        raise SystemExit(f"Cannot bind {url}: {exc}. Close the existing instance or choose another port.") from exc
    roots = ", ".join(SCAN.get("roots", [])) or "none"
    print(f"b70-launcher on {url}  (models: {len(RECIPES['models'])}, scan roots: {roots})")
    if not args.no_open:
        open_window(url)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        with LOCK:
            for e in DOWNLOADS.values():
                e["cancel"] = True
            for e in RUNNING.values():
                if e.get("proc") and e["proc"].poll() is None:
                    e["proc"].terminate()
        print("bye")


if __name__ == "__main__":
    main()
